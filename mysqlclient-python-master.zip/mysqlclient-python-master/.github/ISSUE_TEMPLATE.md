**IF YOU HAVE SOME TROUBLE, IT'S MAY NOT ISSUE OF THIS PROJECT. GO STACKOVERFLOW!!!**

If you failed to build, go Stackoverflow.
If you failed to install, go Stackoverflow.
If you failed to connect to database, go Stackoverflow.

FYI, MySQL Connector/C 6.1.10 has bug. see https://github.com/PyMySQL/mysqlclient-python/issues/169#issuecomment-299778504

Only when If you're sure it's PyMySQL's issue, report the complete steps to reproduce, from creating database.

I don't have time to investigate your issue from an incomplete code snippet.

See also: https://medium.com/@methane/why-you-must-not-ask-questions-on-github-issues-51d741d83fde
